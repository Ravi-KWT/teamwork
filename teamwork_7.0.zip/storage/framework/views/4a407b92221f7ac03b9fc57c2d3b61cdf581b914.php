<nav class="page-sidebar" data-pages="sidebar" id="leftmenu">
<div class="mCustomScrollbar" data-mcs-theme="minimal-dark" data-height="100%">
<div class="panel">
    <div class="panel-heading">Categories</div>
    <div class="panel-body">
        <ul>
            <?php $__empty_1 = true; $__currentLoopData = $task_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php
                    $count = 0;
                    foreach($tasks as $task)
                    {
                        if($task->category_id == $task_category->id)
                        {
                            $count++;
                        }
                    }
                ?>

                <li >
                    <a href="<?php echo e(url('/task-categories',$task_category->id)); ?>">
                    <?php echo e($task_category->name); ?>

                        <span class="badge">
                            <?php echo e($count); ?>

                        </span>
                    </a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
               No Category
            <?php endif; ?>
        </ul>
    </div>
</div>
</div>
</nav>
<?php /**PATH /var/www/html/demo/teamwork_7.0/resources/views/shared/project_detail.blade.php ENDPATH**/ ?>