<div class="header">
	<nav class="navbar">
		<div class="container-fluid">
			<div class="navbar-header">
				<a class="navbar-brand" href="<?php echo url('/'); ?>">
					<img src="<?php echo asset('img/logo.png'); ?>" alt="logo" data-src="<?php echo asset('img/logo.png'); ?>" data-src-retina="<?php echo asset('img/logo_2x.png'); ?>">
				</a>
			</div>
			<div class="header-profile">
				<ul class="list-inline">
					<li>
						<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#menu" aria-expanded="false">
						<i class="fa fa-align-justify"></i>
						</button>
					</li>
					<li class="dropdown drop-arrow rightside">
						<button class="btn btn-md btn-trans" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
						<?php if(Auth::check()): ?>
						<span class="name">
                            <?php if(Auth::user()->people): ?>
                                <?php if(Auth::user()->people->fname==null): ?>
    							     <?php echo Auth::user()->email; ?>

    							<?php else: ?>
    							     <?php echo ucwords( Auth::user()->people->fname." ".Auth::user()->people->lname); ?>

    							<?php endif; ?>
                            <?php else: ?>
                                <?php echo Auth::user()->email; ?>

                            <?php endif; ?>
						</span>
						<?php endif; ?>
						<?php if(Auth::check()): ?>
						<div class="avtar inline">
                            <?php if(Auth::user()->people): ?>
    							<?php if(Auth::user()->people->photo): ?>
        							<div class='img avatar-xs'>
        								<img src="<?php echo Auth::user()->people->photo_url('thumb'); ?>">
        							</div>
    							<?php else: ?>
        							<div class='img avatar-xm'>
        								<img src="/img/user.png">
        							</div>
    							<?php endif; ?>
                            <?php else: ?>
                                <div class='img avatar-xm'>
                                    <img src="/img/user.png">
                                </div>
                            <?php endif; ?>
						</div>
						<?php endif; ?>
						</button>
						<ul class="dropdown-menu" role="menu">
							
							<li><a href="<?php echo url('/change-password'); ?>">Change Password</a></li>
							<li><a href="<?php echo url('change-profile'); ?>">Change Profile</a></li>
							<li><a href="<?php echo url('theme'); ?>">Theme</a></li>
							<li class="bg-master-lighter">
								<a href="javascript:;" onclick="document.getElementById('logout-form').submit();">Logout</a>
							</li>
						        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
						            <?php echo csrf_field(); ?>
						            <input type="hidden" name="fcm_token" value="" id="fcm_token">
						        </form>
						</ul>
					</li>
					<li>
						<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#leftmenu" aria-expanded="false">
						<i class="fa fa-align-justify"></i>
						</button>
					</li>
				</ul>
			</div>
			<div class="collapse navbar-collapse" id="menu">
				<ul class="navbar-nav">
					<li class="<?php echo e(Route::currentRouteNamed('home') ? 'active' : ''); ?>"><a href="<?php echo url('/'); ?>">Home</a></li>
                    <?php if(Auth::user()->roles=='admin'): ?>
    					<li class="<?php echo e(Route::currentRouteNamed('companies') ? 'active' : ''); ?> dropdown drop-arrow">
    						<a href="<?php echo url('companies'); ?>" class='company active' data-id='company'>Company
    						</a>
    						<?php if(Auth::user()->roles == 'admin'): ?>
    						<div class="togg" data-toggle="dropdown" id="drop_1">
    							<span class="caret"></span>
    						</div>
    						<ul class="dropdown-menu" aria-labelledby="drop_1">
    							<li class="<?php echo e(Route::currentRouteNamed('industries') ? 'active' : ''); ?>">
    								<a href="<?php echo url('industries'); ?>" class="industry"    data-id='industry'>Industry</a>
    							</li>
    						</ul>
    						<?php endif; ?>
    					</li>
                    <?php endif; ?>
				
					<li class="<?php if(Route::currentRouteNamed('projects')): ?>
									active
								<?php elseif(Route::currentRouteNamed('projects-list')): ?>
									active
								<?php elseif(Route::currentRouteNamed('search-projects')): ?>
									active
								<?php else: ?>
									''
								<?php endif; ?> dropdown drop-arrow">
						<a href="<?php echo url('projects'); ?>" class='project'  data-id='project'>Projects
						</a>
						<?php if(Auth::user()->roles == 'admin'): ?>
						<div class="togg" data-toggle="dropdown" id="drop_3">
							<span class="caret"></span>
						</div>
						<ul class="dropdown-menu">
							<li class="<?php echo e(Route::currentRouteNamed('project-categories') ? 'active' : ''); ?>" >
								<a href="<?php echo url('project-categories'); ?>" class='project_cat' data-id='project_cat'>Project Category
								</a>
							</li>
							<li class="<?php echo e(Route::currentRouteNamed('task-categories') ? 'active' : ''); ?>">
								<a href="<?php echo url('task-categories'); ?>" class='task_cat' data-id='task_cat'>Task Category
								</a>
							</li>
						</ul>
						<?php endif; ?>
					</li>
                    <li class="<?php echo e(Route::currentRouteNamed('everything') ? 'active' : ''); ?>"><a href="<?php echo url('everything'); ?>" class='everything' data-id='everything'>Everything</a></li>
              
                    <li class="<?php echo e(Route::currentRouteNamed('people') ? 'active' : ''); ?> dropdown drop-arrow">
                        <a href="<?php echo url('people'); ?>" class='people'   data-id='people'>People
                        </a>
                        <?php if(Auth::user()->roles == 'admin'): ?>
                        <div class="togg" data-toggle="dropdown" id="drop_2">
                            <span class="caret"></span>
                        </div>
                        <ul class="dropdown-menu" aria-labelledby="drop_2">
                            <li class="<?php echo e(Route::currentRouteNamed('designations') ? 'active' : ''); ?>">
                                <a href="<?php echo url('designations'); ?>" class='designation'     data-id='designation'>Designation</a>
                            </li>
                            <li class="<?php echo e(Route::currentRouteNamed('department') ? 'active' : ''); ?>">
                                <a href="<?php echo url('departments'); ?>" class='department' data-id='department' >Department</a>
                            </li>
                        </ul>
                        <?php endif; ?>
                    </li>
                   	 <li class="<?php echo e(Route::currentRouteNamed('resources') ? 'active' : ''); ?>"><a href="<?php echo url('resources'); ?>" class='resources' data-id='resources'>Resources</a></li>
                

                
                    <?php if(Auth::user()->roles == 'admin' ): ?>
                    	 <li class="<?php echo e(Route::currentRouteNamed('team-members') ? 'active' : ''); ?>"><a href="<?php echo url('team-members'); ?>" class='resources' data-id='resources'>Teams</a></li>
                    <?php endif; ?>
                    <li class="<?php echo e(Route::currentRouteNamed('birthdays') ? 'active' : ''); ?>"><a href="<?php echo route('birthdays'); ?>" class='birthdays' data-id='birthdays'>Birthday</a></li>
                    <?php if(Auth::user()->roles == "admin" && Auth::user()->is_teamlead == false): ?>
                    	<li class="<?php echo e(Route::currentRouteNamed('current-projects') ? 'active' : ''); ?>"><a href="<?php echo route('current-projects'); ?>" class='current-projects' data-id='current-projects'>Going Projects</a></li>
                    <?php endif; ?>
                    

                    

                    
				</ul>
			</div>
		</div>
	</nav>
	<div class="page-header">
		<div class="container-fluid">
			<?php if(Request::segment(1) == ''): ?>
			<h1>Dashboard</h1>
			<?php elseif(Request::segment(1) == 'companies'): ?>
			<h1>Company</h1>
			<?php elseif(Request::segment(1) == 'industries'): ?>
			<h1>Industry</h1>
			<?php elseif(Request::segment(1) == 'departments'): ?>
			<h1>Department</h1>
			<?php elseif(Request::segment(1) == 'designations'): ?>
			<h1>Designation</h1>
			<?php elseif(Request::segment(1) == 'everything'): ?>

			<h1>Everything</h1>
            <?php elseif(Request::segment(1) == 'change-profile'): ?>

            <h1>Change Profile</h1>
            <?php elseif(Request::segment(1) == 'change-password'): ?>

            <h1>Change Password</h1>
            
			<?php elseif(Request::segment(1) == 'people'): ?>
			<h1>People</h1>
			<?php elseif(Request::segment(1) == 'birthdays'): ?>
			<h1>BIRTHDAY BUDDIES</h1>
			
			<?php elseif(Request::segment(1) == 'projects' && Request::segment(2)): ?>
			<?php 
                $project= \App\Project::find(Request::segment(2));
                if(empty($project))
                {
                    return redirect()->back()->with('error','The project that you want to access does not exist or deleted by Admin');
                }
            ?>
			<h1><a href ="<?php echo url('/projects'),'/',$project->id,'/tasks'; ?>"><?php echo e(ucwords($project->name)); ?></a></h1>
			<h2>( <?php echo e(ucwords($project->company->name)); ?> ) </h2>
			<div class="loggedhours text-right <?php echo e($project->price_types!='fix'?'not-fix-log':''); ?>">
				<div class="row">
                    <?php if($project->price_types=='fix'): ?>
                    <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                        <div class="fixhours text-right">
                            <span>Estimated Hours</span><strong><?php echo e($project->fix_hours); ?> hrs</strong>
                        </div>
                    </div>
                    <?php endif; ?>
					<div class="col-lg-<?php echo $project->price_types=='fix'?'8':'12'; ?> col-md-<?php echo $project->price_types=='fix'?'8':'12'; ?> col-sm-<?php echo $project->price_types=='fix'?'8':'12'; ?> col-xs-12">
						<div class="row">
							<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
								<div class="billables">
									<span class="title">Billable</span>
									<span class="count"><?php echo e($billable_hours); ?> hrs</span>
								</div>
							</div>
							<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
								<div class="nonbillables">
									<span class="title">Non Billable</span>
									<span class="count"><?php echo e($non_billable_hours); ?> hrs</span>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<?php elseif(Request::segment(1) == 'projects' && Request::segment(2)): ?>
			<?php $project= \App\Project::find(Request::segment(2));?>
    			<h1>
    			<?php echo e(ucwords($project->name)); ?>

    			</h1>
			<h2>( <?php echo e(ucwords($project->company->name)); ?> )</h2>
			<?php elseif(Request::segment(1) == 'projects' || Route::currentRouteNamed('search-projects')): ?>
			 <h1>Projects</h1>
			<?php elseif(Request::segment(1) == 'project-categories'): ?>
		  	<h1>Project Category</h1>
			<?php elseif(Request::segment(1) == 'task-categories'): ?>
			 <h1>Task Category</h1>
            <?php elseif(Request::segment(1) == 'theme'): ?>
              <h1>Theme Setting</h1>
             <?php elseif(Request::segment(1) == 'resources' || Request::segment(1) == 'filter-resource-availability'): ?>
             	 <h1>Resource Availability</h1>
             <?php elseif(Request::segment(1) == 'team-members'): ?>
             	<h1>Teams</h1>
             <?php elseif(Request::segment(1) == 'user-permissions'): ?>
             	<h1>User Permission</h1>
            <?php else: ?>
                <h1>&nbsp;</h1>
			<?php endif; ?>
		</div>
	</div>
</div><?php /**PATH /var/www/html/demo/teamwork_7.0/resources/views/shared/header.blade.php ENDPATH**/ ?>