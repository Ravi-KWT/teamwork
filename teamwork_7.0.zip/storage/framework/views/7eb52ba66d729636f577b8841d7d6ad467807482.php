<?php $__env->startSection('title','Everything'); ?>
<?php $__env->startSection('content'); ?>
    <div class="page-user-log ">
        <?php echo $__env->make('shared.user_login_detail', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="container-fluid">
        <ul class="breadcrumb" ng-cloak>
            <li><a href="<?php echo url('/'); ?>"><span><i class="fa fa-home"></i></span></a></li>

            
            <li class="active"><span>Everything</span></li>
        </ul>
        <div class="panel panel-transparent">
            <div class="panel-heading clearfix">
                <div class="panel-title">Filter Now</div>
            </div>
            <div class="panel-body">
                 <?php echo $__env->make('shared.session', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  
                  <div class="filtter clearfix">
                    <div class="container-fluid">
                        <div class="row">

                            <form name='searchEverythingTask' action="<?php echo route('searchEverything'); ?>" method="get" class='form' role='form')
                           
                            >
                                <div class="col-lg-10 col-md-10 col-sm-10 col-xs-12">
                                    <div class="form-inline">
                                       <?php if(Auth::user()->roles=='admin' || Auth::user()->is_teamlead==true || Auth::user()->is_projectlead==true): ?>
                                        <div class="form-group" ng-cloak>
                                            <label class="label"><span>Users</span></label>
                                             <?php echo Former::select("user_id","")->options($users ); ?>

                                        </div>
                                        <?php endif; ?>
                                        <div class="form-group">
                                            <div class="form-group" >
                                                <label class="label"><span>Date Range</span></label>
                                                <div class="input-group datepicker" date-set="
                                                <?php if(isset($start_date)): ?>
                                                   <?php echo $start_date; ?>

                                                <?php else: ?>

                                                    <?php echo Carbon\Carbon::now()->subdays(2); ?>

                                                <?php endif; ?>"
                                                date-format="yyyy-MM-dd" date-max-limit="{% searchForm.end_date %}" selector="form-control"
                                                    >
                                                    <input type="text" name="start_date" class="form-control" placeholder="Pick a start date" id="searchForm-start-date" ng-model="searchForm.start_date " readonly>
                                                    <label class="input-group-addon" for="searchForm-start-date">
                                                        <i class="fa fa-calendar"></i>
                                                    </label>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                               <i class="fa fa-arrows-h"></i>
                                            </div>
                                            <div class="form-group">
                                                <div class="input-group datepicker" date-set="
                                                <?php if(isset($end_date)): ?>
                                                   <?php echo $end_date; ?>

                                                <?php else: ?>
                                                    <?php echo Carbon\Carbon::now(); ?>

                                                <?php endif; ?>" date-format="yyyy-MM-dd" date-min-limit="{% searchForm.start_date %}" >
                                                    <input type="text"  name="end_date" class="form-control" placeholder="Pick a end date" id="searchForm-end-date" ng-model = 'searchForm.end_date' readonly>
                                                    <label class="input-group-addon" for="searchForm-end-date">
                                                        <i class="fa fa-calendar"></i>
                                                    </label>
                                                   
                                                </div>
                                            </div>
                                        </div>

                                     
                                       
                                        <div class="form-group">
                                        
                                            <label class="label"><span>Projects</span></label>
                                            <?php echo Former::select("project_id","")->options($projectsList); ?>

                                        </div>

                                       <?php if(Auth::user()->roles=='admin' ): ?>
                                           <?php if(Auth::user()->is_teamlead == false): ?>
                                               <div class="form-group">
                                                   <label class="label"><span>Departments</span></label>
                                                   <?php echo Former::select("department_id","")->options($departmentList); ?>

                                               </div>
                                           <?php endif; ?>
                                            <div class="form-group">
                                                <label class="label"><span>Company/Client</span></label>
                                                <?php echo Former::select("client_id","")->options($companyList)->setAttributeData('size','2'); ?>

                                            </div>
                                        <?php endif; ?>
                                        <div class="form-group">
                                            <label class="label"><span>Log Type</span></label>
                                            <?php echo Former::select("billable","")->options([''=>'All Logs','true'=>'Billable','false'=>'Non-Billable'] ); ?>

                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
                                    <ul class="list-inline">
                                        <li>
                                        <div class="form-group">
                                            <label class="label">&nbsp;</label>
                                            <button type="submit" class="btn btn-fltr btn-md btn-default">FILTER</button>
                                        </div>
                                        </li>
                                        <?php if($l!=0): ?>
                                            <li>
                                                <div class="form-group">
                                                    <label class="label">&nbsp;</label>
                                                    <div class="dropdown drop-arrow rightside padd">
                                                        <button class="btn btn-md btn-default" type="button" id="export" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                                                              EXPORT
                                                             <span class="caret"></span>
                                                        </button>
                                                        <ul class="dropdown-menu" aria-labelledby="export">
                                                            <li>
                                                                <button  class="btn-block btn btn-sm btn-default btn-report" type="submit" name="excel" value="Excel">Excel</button>
                                                            </li>
                                                            <?php if(Auth::user()->roles=='admin'): ?>
                                                                <li>
                                                                    <button  class="btn-block btn btn-sm btn-default btn-report" type="submit" name="pdf" value="PDF" >PDF</button>
                                                                </li>
                                                                <li>
                                                                    <button  class="btn-block btn btn-sm btn-default btn-report" type="submit" name="pdfProjectsReport" value="pdfProjectsReport">PDF Client Projects</button>
                                                                </li>
                                                            <?php endif; ?>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </li>
                                        <?php endif; ?>
                                    </ul>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
               <?php if(count($logs)): ?>
            <div class="panel-footer">
                <div class="row">
                    <div class="col-lg-10 col-md-10 col-sm-10 col-xs-12">
                        <div class="filter-total" ng-cloak>
                            <div class="hours-count" ng-cloak >
                                <label>Filtered Totals:</label>
                                <div class="logged-hours"  ng-cloak>
                                    <strong>Logged:</strong>
                                        
                                        <?php echo floor($totalLoggedHours/60)."
                                Hours ".($totalLoggedHours%60)." Minutes ( "
                                  . number_format($totalLoggedHours/60,2); ?> )
                                </div>
                                <div class="billable-hours"  ng-cloak>
                                    <strong>Billable:</strong>
                                        <?php echo floor($totalBillableHours/60)."
                                Hours ".($totalBillableHours%60)." Minutes ( "
                                  . number_format($totalBillableHours/60,2); ?> )
                                </div>
                                <div class="non-billable-hours"  ng-cloak>
                                    <strong>Non-billable:</strong>
                                      <?php echo Floor($totalNonBillableHours/60)."
                                Hours ".($totalNonBillableHours%60)." Minutes ( "
                                  . number_format($totalNonBillableHours/60,2); ?> )
                                </div>

                            </div>
                        </div>
                    </div>
                   
                    <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12 text-right">
                    </div>
                    
                </div>
            </div>
            <?php endif; ?>
        </div>
        <div class="panel panel-transparent">
            <div class="panel-heading clearfix">
                <div class="panel-title">All Logs</div>
                <div class="action">
                    
                </div>
            </div>
            <?php if(Auth::user()->roles=='admin'): ?>
            <div class="panel-body" ng-cloak>
                 
                <div ng-cloak   class="loader" ng-if="loading"></div>

                    <?php $__empty_1 = true; $__currentLoopData = $logAllUserList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $logUser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                        <?php
                            $dateWiseLoggedHours = 0;
                            $dateWiseBillableHours = 0;
                            $dateWiseNonBillableHours = 0;
                        ?>
                        <div class="everything-date">
                            <h2><a href="<?php echo e(url('/people',$key)); ?>"><?php echo $logUser; ?></a></h2>
                        </div>
                        <table  class="table table-striped example vc dataAdmin" data-paging="false" data-searching="false" data-info="false">
                            <thead>
                                <th class="text-left">Project Name</th>
                                <th>Date</th> 
                             
                                <th>Description</th>
                                <th>Task list</th>
                                <th>start Time</th>
                                <th>End Time</th>
                                <th>Billable</th>
                                <th>Hours</th>
                                
                            </thead>
                                    <tbody >
                                     <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $everythingLog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($everythingLog->user->people->fname.($everythingLog->user->people->lname?" ".$everythingLog->user->people->lname:'')==$logUser): ?>
                                        <tr class="text-left"  >
                                            <td>
                                                <a href="<?php echo url('/projects'),'/',$everythingLog->task->project->id,'/tasks'; ?>"><?php echo $everythingLog->task->project->name; ?></a>
                                            </td>
                                           
                                            <td >
                                                <span style="display: none;"><?php echo $everythingLog->date? \Carbon\Carbon::parse($everythingLog->date)->format('Ymd'):'-'; ?> </span>
                                                <?php echo $everythingLog->date? \Carbon\Carbon::parse($everythingLog->date)->format('d-m-Y'):'-'; ?> 
                                                
                                            </td>
                                           
                                            <td>
                                                <div>
                                                    <div class="task">
                                                        Task: <a href="<?php echo url('/projects'),'/',$everythingLog->project_id,'/tasks','/',$everythingLog->task_id; ?>"><?php echo $everythingLog->task->name; ?></a>
                                                    </div>
                                                    <div class="task-discription ellipsisH" title="<?php echo $everythingLog->description; ?>" data-toggle="tooltip" data-placement="bottom">
                                                        <?php echo $everythingLog->description; ?>

                                                    </div>
                                                </div>
                                            </td>
                                            <td>
                                                <?php echo $everythingLog->task->category->name ? $everythingLog->task->category->name : '-'; ?>

                                            </td>
                                            <td>
                                                <?php echo $everythingLog->start_time ? $everythingLog->start_time : '-'; ?>

                                            </td>
                                            <td>
                                                <?php echo $everythingLog->end_time ? $everythingLog->end_time : '-'; ?>

                                            </td>

                                            <td >
                                                <?php if($everythingLog->billable): ?>
                                                    <span class="billable" style="cursor: default;">
                                                        <i class="fa fa-check"></i>
                                                    </span>
                                                <?php else: ?>
                                                    <span class="nobillable" style="cursor: default;">
                                                        <i class="fa fa-close"></i>
                                                    </span>

                                                <?php endif; ?>
                                            </td>

                                            <td ng-cloak>
                                                <?php echo $everythingLog->hour ? $everythingLog->hour : '-'; ?>

                                            </td>
                                       
                                        </tr>
                                         <?php
                                            if($everythingLog->billable == 'true'){
                                                $dateWiseBillableHours +=  $everythingLog->minute;
                                            }
                                            else {
                                                $dateWiseNonBillableHours +=  $everythingLog->minute;
                                            }
                                        ?>
                                         <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                            
                        </table>
                        <div class="filter-total text-right everything">
                                <strong>Logged:</strong> <?php echo floor(($dateWiseBillableHours+$dateWiseNonBillableHours)/60)."
                                    Hours ".(($dateWiseBillableHours+$dateWiseNonBillableHours)%60)." Minutes ( "
                                      . number_format(($dateWiseBillableHours+$dateWiseNonBillableHours)/60,2); ?> )
                                      
                                <strong>Billable:</strong>  <?php echo floor($dateWiseBillableHours/60)."
                                    Hours ".($dateWiseBillableHours%60)." Minutes ( "
                                      . number_format($dateWiseBillableHours/60,2); ?> )

                                <strong>Non-billable:</strong> <?php echo floor($dateWiseNonBillableHours/60)."
                                    Hours ".($dateWiseNonBillableHours%60)." Minutes ( "
                                      . number_format($dateWiseNonBillableHours/60,2); ?> )
                            </div>
                       
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div ng-cloak class="col-md-12">
                                <div class="no-record-found">
                                    <h3>No record found</h3>
                                </div>
                            </div>
                        <?php endif; ?>

                    </div>

            </div>
            <?php elseif(Auth::user()->roles == 'employee' && Auth::user()->is_projectlead == true): ?>
            <div class="panel-body" ng-cloak>
                 
                <div ng-cloak   class="loader" ng-if="loading"></div>

                    <?php $__empty_1 = true; $__currentLoopData = $logAllUserList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $logUser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        
                        <?php
                            $dateWiseLoggedHours = 0;
                            $dateWiseBillableHours = 0;
                            $dateWiseNonBillableHours = 0;
                        ?>
                        <div class="everything-date">
                            <h2><a href="<?php echo e(url('/people',$key)); ?>"><?php echo $logUser; ?></a></h2>
                        </div>
                        <table  class="table table-striped example vc dataAdmin" data-paging="false" data-searching="false" data-info="false">
                            <thead>
                                <th class="text-left">Project Name</th>
                                <th>Date</th> 
                             
                                <th>Description</th>
                                <th>Task list</th>
                                <th>start Time</th>
                                <th>End Time</th>
                                <th>Billable</th>
                                <th>Hours</th>
                                
                            </thead>
                                    <tbody >
                                     <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $everythingLog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($everythingLog->user->people->fname.($everythingLog->user->people->lname?" ".$everythingLog->user->people->lname:'')==$logUser): ?>
                                        <tr class="text-left"  >
                                            <td>
                                                <a href="<?php echo url('/projects'),'/',$everythingLog->task->project->id,'/tasks'; ?>"><?php echo $everythingLog->project->name; ?></a>
                                            </td>
                                           
                                            <td >
                                                <span style="display: none;"><?php echo $everythingLog->date? \Carbon\Carbon::parse($everythingLog->date)->format('Ymd'):'-'; ?> </span>
                                                <?php echo $everythingLog->date? \Carbon\Carbon::parse($everythingLog->date)->format('d-m-Y'):'-'; ?> 
                                                
                                            </td>
                                           
                                            <td>
                                                <div>
                                                    <div class="task">
                                                        Task: <a href="<?php echo url('/projects'),'/',$everythingLog->project_id,'/tasks','/',$everythingLog->task_id; ?>"><?php echo $everythingLog->task->name; ?></a>
                                                    </div>
                                                    <div class="task-discription ellipsisH" title="<?php echo $everythingLog->description; ?>" data-toggle="tooltip" data-placement="bottom">
                                                        <?php echo $everythingLog->description; ?>

                                                    </div>
                                                </div>
                                            </td>
                                            <td>
                                                <?php echo $everythingLog->task->category->name ? $everythingLog->task->category->name : '-'; ?>

                                            </td>
                                            <td>
                                                <?php echo $everythingLog->start_time ? $everythingLog->start_time : '-'; ?>

                                            </td>
                                            <td>
                                                <?php echo $everythingLog->end_time ? $everythingLog->end_time : '-'; ?>

                                            </td>

                                            <td >
                                                <?php if($everythingLog->billable): ?>
                                                    <span class="billable" style="cursor: default;">
                                                        <i class="fa fa-check"></i>
                                                    </span>
                                                <?php else: ?>
                                                    <span class="nobillable" style="cursor: default;">
                                                        <i class="fa fa-close"></i>
                                                    </span>

                                                <?php endif; ?>
                                            </td>

                                            <td ng-cloak>
                                                <?php echo $everythingLog->hour ? $everythingLog->hour : '-'; ?>

                                            </td>
                                       
                                        </tr>
                                         <?php
                                            if($everythingLog->billable == 'true'){
                                                $dateWiseBillableHours +=  $everythingLog->minute;
                                            }
                                            else {
                                                $dateWiseNonBillableHours +=  $everythingLog->minute;
                                            }
                                        ?>
                                         <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                            
                        </table>
                        <div class="filter-total text-right everything">
                                <strong>Logged:</strong> <?php echo floor(($dateWiseBillableHours+$dateWiseNonBillableHours)/60)."
                                    Hours ".(($dateWiseBillableHours+$dateWiseNonBillableHours)%60)." Minutes ( "
                                      . number_format(($dateWiseBillableHours+$dateWiseNonBillableHours)/60,2); ?> )
                                      
                                <strong>Billable:</strong>  <?php echo floor($dateWiseBillableHours/60)."
                                    Hours ".($dateWiseBillableHours%60)." Minutes ( "
                                      . number_format($dateWiseBillableHours/60,2); ?> )

                                <strong>Non-billable:</strong> <?php echo floor($dateWiseNonBillableHours/60)."
                                    Hours ".($dateWiseNonBillableHours%60)." Minutes ( "
                                      . number_format($dateWiseNonBillableHours/60,2); ?> )
                            </div>
                       
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div ng-cloak class="col-md-12">
                                <div class="no-record-found">
                                    <h3>No record found</h3>
                                </div>
                            </div>
                        <?php endif; ?>

                    </div>

            </div>
            <?php elseif(Auth::user()->is_teamlead == true): ?>
            <div class="panel-body" ng-cloak>
                 
                <div ng-cloak   class="loader" ng-if="loading"></div>

                    <?php $__empty_1 = true; $__currentLoopData = $logAllUserList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $logUser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                        <?php
                            $dateWiseLoggedHours = 0;
                            $dateWiseBillableHours = 0;
                            $dateWiseNonBillableHours = 0;
                        ?>
                        <div class="everything-date">
                            <h2><a href="<?php echo e(url('/people',$key)); ?>"><?php echo $logUser; ?></a></h2>
                        </div>
                        <table  class="table table-striped example vc dataAdmin" data-paging="false" data-searching="false" data-info="false">
                            <thead>
                                <th class="text-left">Project Name</th>
                                <th>Date</th> 
                             
                                <th>Description</th>
                                <th>Task list</th>
                                <th>start Time</th>
                                <th>End Time</th>
                                <th>Billable</th>
                                <th>Hours</th>
                                
                            </thead>
                                    <tbody >
                                     <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $everythingLog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($everythingLog->user->people->fname.($everythingLog->user->people->lname?" ".$everythingLog->user->people->lname:'')==$logUser): ?>
                                        <tr class="text-left"  >
                                            <td>
                                                <a href="<?php echo url('/projects'),'/',$everythingLog->task->project->id,'/tasks'; ?>"><?php echo $everythingLog->project->name; ?></a>
                                            </td>
                                           
                                            <td >
                                                <span style="display: none;"><?php echo $everythingLog->date? \Carbon\Carbon::parse($everythingLog->date)->format('Ymd'):'-'; ?> </span>
                                                <?php echo $everythingLog->date? \Carbon\Carbon::parse($everythingLog->date)->format('d-m-Y'):'-'; ?> 
                                                
                                            </td>
                                           
                                            <td>
                                                <div>
                                                    <div class="task">
                                                        Task: <a href="<?php echo url('/projects'),'/',$everythingLog->project_id,'/tasks','/',$everythingLog->task_id; ?>"><?php echo $everythingLog->task->name; ?></a>
                                                    </div>
                                                    <div class="task-discription ellipsisH" title="<?php echo $everythingLog->description; ?>" data-toggle="tooltip" data-placement="bottom">
                                                        <?php echo $everythingLog->description; ?>

                                                    </div>
                                                </div>
                                            </td>
                                            <td>
                                                <?php echo $everythingLog->task->category->name ? $everythingLog->task->category->name : '-'; ?>

                                            </td>
                                            <td>
                                                <?php echo $everythingLog->start_time ? $everythingLog->start_time : '-'; ?>

                                            </td>
                                            <td>
                                                <?php echo $everythingLog->end_time ? $everythingLog->end_time : '-'; ?>

                                            </td>

                                            <td >
                                                <?php if($everythingLog->billable): ?>
                                                    <span class="billable" style="cursor: default;">
                                                        <i class="fa fa-check"></i>
                                                    </span>
                                                <?php else: ?>
                                                    <span class="nobillable" style="cursor: default;">
                                                        <i class="fa fa-close"></i>
                                                    </span>

                                                <?php endif; ?>
                                            </td>

                                            <td ng-cloak>
                                                <?php echo $everythingLog->hour ? $everythingLog->hour : '-'; ?>

                                            </td>
                                       
                                        </tr>
                                         <?php
                                            if($everythingLog->billable == 'true'){
                                                $dateWiseBillableHours +=  $everythingLog->minute;
                                            }
                                            else {
                                                $dateWiseNonBillableHours +=  $everythingLog->minute;
                                            }
                                        ?>
                                         <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                            
                        </table>
                        <div class="filter-total text-right everything">
                                <strong>Logged:</strong> <?php echo floor(($dateWiseBillableHours+$dateWiseNonBillableHours)/60)."
                                    Hours ".(($dateWiseBillableHours+$dateWiseNonBillableHours)%60)." Minutes ( "
                                      . number_format(($dateWiseBillableHours+$dateWiseNonBillableHours)/60,2); ?> )
                                      
                                <strong>Billable:</strong>  <?php echo floor($dateWiseBillableHours/60)."
                                    Hours ".($dateWiseBillableHours%60)." Minutes ( "
                                      . number_format($dateWiseBillableHours/60,2); ?> )

                                <strong>Non-billable:</strong> <?php echo floor($dateWiseNonBillableHours/60)."
                                    Hours ".($dateWiseNonBillableHours%60)." Minutes ( "
                                      . number_format($dateWiseNonBillableHours/60,2); ?> )
                            </div>
                       
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div ng-cloak class="col-md-12">
                                <div class="no-record-found">
                                    <h3>No record found</h3>
                                </div>
                            </div>
                        <?php endif; ?>

                    </div>

            </div>
            <?php else: ?>
             <div class="panel-body" ng-cloak>
                <div ng-cloak   class="loader" ng-if="loading"></div>
                <?php echo $__env->make('shared.session', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php $__empty_1 = true; $__currentLoopData = $logDates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $logDateUnique): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php
                            $dateWiseLoggedHours = 0;
                            $dateWiseBillableHours = 0;
                            $dateWiseNonBillableHours = 0;
                        ?>
                        <div class="everything-date">
                                
                            <h2><?php echo \Carbon\Carbon::parse($logDateUnique)->format('l, d F'); ?></h2>
                        </div>
                        <table  class="table table-striped example vc dataAdmin dataTable"  data-paging="false" data-searching="false" data-info="false" >
                            <thead>
                                <th class="text-left">Project Name</th>
                                <th>Description</th>
                                <th>Task list</th>
                                <th>Start Time</th>
                                <th>End Time</th>
                                <th>Billable</th>
                                <th>Hours</th>
                                
                            </thead>
                                <tbody >
                                     <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $everythingLog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <?php if($everythingLog->date == $logDateUnique): ?>
                                        <tr class="text-left">
                                            <td>
                                                <a href="<?php echo url('/projects'),'/',$everythingLog->project_id,'/tasks'; ?>"><?php echo $everythingLog->task->project->name; ?></a>
                                            </td>
                                            <td>
                                    
                                                    <div class="task">
                                                        Task: <a href="<?php echo url('/projects'),'/',$everythingLog->project_id,'/tasks','/',$everythingLog->task_id; ?>"><?php echo $everythingLog->task->name; ?></a>
                                                    </div>
                                                    <div class="task-discription ellipsisH" title="<?php echo $everythingLog->description; ?>" data-toggle="tooltip" data-placement="bottom">
                                                        <?php echo $everythingLog->description; ?>

                                                    </div>
                                   
                                            </td>
                                            <td>
                                                <?php echo $everythingLog->task->category->name ? $everythingLog->task->category->name : '-'; ?>

                                            </td>
                                            <td>
                                                <?php echo $everythingLog->start_time ? $everythingLog->start_time : '-'; ?>

                                            </td>
                                            <td>
                                                <?php echo $everythingLog->end_time ? $everythingLog->end_time : '-'; ?>

                                            </td>

                                            <td >
                                                <?php if($everythingLog->billable): ?>
                                                    <span class="billable">
                                                        <i class="fa fa-check"></i>
                                                    </span>
                                                <?php else: ?>
                                                    <span class="nobillable">
                                                        <i class="fa fa-close"></i>
                                                    </span>

                                                <?php endif; ?>
                                            </td>

                                            <td ng-cloak>
                                                <?php echo $everythingLog->hour ? $everythingLog->hour : '-'; ?>

                                            </td>
                                       
                                        </tr>
                                         <?php
                                            if($everythingLog->billable == 'true'){
                                                $dateWiseBillableHours +=  $everythingLog->minute;
                                            }
                                            else {
                                                $dateWiseNonBillableHours +=  $everythingLog->minute;
                                            }
                                        ?>
                                         <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                            
                        </table>
                        <div class="filter-total text-right everything">
                                <strong>Logged:</strong> <?php echo floor(($dateWiseBillableHours+$dateWiseNonBillableHours)/60)."
                                    Hours ".(($dateWiseBillableHours+$dateWiseNonBillableHours)%60)." Minutes ( "
                                      . number_format(($dateWiseBillableHours+$dateWiseNonBillableHours)/60,2); ?> )
                                      
                                <strong>Billable:</strong>  <?php echo floor($dateWiseBillableHours/60)."
                                    Hours ".($dateWiseBillableHours%60)." Minutes ( "
                                      . number_format($dateWiseBillableHours/60,2); ?> )

                                <strong>Non-billable:</strong> <?php echo floor($dateWiseNonBillableHours/60)."
                                    Hours ".($dateWiseNonBillableHours%60)." Minutes ( "
                                      . number_format($dateWiseNonBillableHours/60,2); ?> )
                            </div>
                       
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div ng-cloak class="col-md-12">
                                <div class="no-record-found">
                                    <h3>No record found</h3>
                                </div>
                            </div>
                        <?php endif; ?>

                    </div>
                <?php endif; ?>
            </div>

        </div>
    </div>
    <div class="modal fade stick-up" id="logTimeModal" data-keyboard=false data-backdrop='static' tabindex="-1" role="dialog" aria-labelledby="logTimeModal" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header clearfix">
                    <button type="button" class="close" ng-click="logCancel()" data-dismiss="modal" aria-hidden="true"> <i class="fa fa-close"></i></button>
                    <h4>Log time on this task</h4>
                </div>
                <form name="Logtime" ng-submit="submit(Logtime)" class='form' role='form' novalidate>
                    <div class="modal-body">
                        <div class="tab-content">
                            
                            <div class="tab-pane slide-left active" id="loghome">
                                <div class="row">
                                    <div class="col-md-6">
                                        <label class="label"><span>User</span></label>
                                        <div class="form-group">
                                            <input type="text"  value='<?php echo Auth::user()->people->fname.' '. Auth::user()->people->lname; ?>' readonly class="form-control"></input>
                                        </div>
                                    </div>
                                    <div class="col-md-6 ">
                                        <div class="form-group">
                                            
                                            <label class="label"><span>Date</span></label>
                                            <div class="datepicker log-date-picker" date-format="yyyy-MM-dd" selector="form-control">
                                                <div class="input-group">
                                                    <input type="text" name="date" class="form-control" placeholder="Pick a date" id="log-date" ng-model='logtime.date' required >
                                                    <span class="input-group-addon">
                                                        <i class="fa fa-calendar"></i>
                                                    </span>
                                                </div>
                                                <span class="error" ng-show="submitted && Logtime.date.$error.required">* Please select date</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <div><div uib-timepicker ng-model="mytime" ng-change="changed()" hour-step="hstep" minute-step="mstep" show-meridian="ismeridian"></div></div>
                                            <label class="label"><span>Start Time</span></label>
                                            <div class="input-group bootstrap-timepicker">
                                                <input id="timepicker_1" type="text" name="start_time" class="form-control" ng-model="logtime.start_time" placeholder="hh:mm:AM" required>
                                                <span class="input-group-addon"><i class="glyphicon glyphicon-time"></i></span>
                                            </div>
                                            <span class="error" ng-show="submitted && Logtime.start_time.$error.required">* Please select start time</span>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="label"><span>End Time</span></label>
                                            <div class="input-group bootstrap-timepicker">
                                                <input id="timepicker_2" type="text" name="end_time" class="form-control" ng-model="logtime.end_time" placeholder="hh:mm:AM" min-time="{%logtime.start_time%}"  required>
                                                <span class="input-group-addon"><i class="glyphicon glyphicon-time"></i></span>
                                            </div>
                                            <span class="error" ng-show="submitted && Logtime.end_time.$error.required">* Please select start time</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label class="label"><span>Spent Time </span></label>
                                            <input  type="text"  class="form-control"  placeholder="hh" value="{% calc_spent_time(logtime.end_time,logtime.start_time)  %}" readonly>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label class="label"><span>Description</span></label>
                                            <textarea id="description" name="description" type="text" class="form-control" placeholder="Description of Log Time" ng-model='logtime.description' required>
                                            </textarea>
                                            <span class="error" ng-show="submitted && Logtime.description.$error.required">* Please enter log description</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="checkbox check-success">
                                            <input type="checkbox" name="billable" ng-model="logtime.billable" id="k">
                                            <label for="k">Billable</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button id="add-app" type="button" class="btn btn-md btn-default" ng-click="submitLog(Logtime)" ng-bind="edit==false ? 'Add' : 'Edit'" ng-disabled="calc_spent_time(logtime.end_time,logtime.start_time)=='0 min'"></button>
                        <button type="button" class="btn btn-md btn-default" id="close"  ng-click="logClearAll(Logtime)">Close</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>


<script type="text/javascript" src="//cdn.datatables.net/plug-ins/1.10.15/sorting/date-dd-MMM-yyyy.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>
<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" />
<script type="text/javascript">
    $(document).ready(function() {
       $('.example').dataTable( {
            "order": [[ 1, "desc" ]]
        });
       // //  var startD =  moment($('#start_date').val(), 'DD-MM-YYYY').toDate();;
       //  var endD   = moment($('#end_date1').val(), 'DD-MM-YYYY').toDate();
       //  alert(endD);
       // $('input[name="daterange"]').daterangepicker({
       //      startDate: startD,
       //      endDate: endD,
       //      opens: 'left'

       //    }, function(start,end, label) {
       //          $('#start_date').val(start.format('DD-MM-YYYY'));
       //          $('#end_date1').val(end.format('DD-MM-YYYY'));
       //    });
       $(document).on('click','.btn-report',function(){
            $(this).parents('form').attr('target','_blank');
            // $(this).parents('form').submit();
       });
        $(document).on('click','.btn-fltr',function(){
            $(this).parents('form').removeAttr('target');
            $(this).parents('form').submit();
       });
    });

    
</script>

<script type="text/javascript">
    // $(document).ready(function(){
    //     $(document).on('change','#project_category_id',function(e){
    //         e.preventDefault();
    //         var project_category_id = $(this).val();
    //         $.post('<?php echo route('get-projects'); ?>',{project_category_id:project_category_id, "_token": "<?php echo e(csrf_token()); ?>"}, function(response){
                
    //             var options = '';
    //             options += '<option value="">All</option>';

    //             if (response != '') {
    //                 $.each(response, function(key,value){
    //                     options += '<option value="'+key+'">'+ value +'</option>';
    //                 }) 

    //                 $('#project_id').html(options);
    //             }else{

    //                 $('#project_id ').html(options);
    //             }
                
                
    //         })
    //     })
    // })
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/demo/teamwork_7.0/resources/views/tasks/everything.blade.php ENDPATH**/ ?>