<?php $__env->startSection('title','People'); ?>
<?php $__env->startSection('content'); ?>
<div ng-controller="PeopleCtrl">
	<div class="content">
		<div class="per-profile">
			<div class="name-pic">
				<div class="avtar inline">
					<div class="img avatar-sm">
						<?php if($people->photo == ''): ?>
							<img src="<?php echo asset('img/noPhoto.png'); ?>" />
						<?php else: ?>
							<img src="<?php echo $people->photo_url(); ?>" />
						<?php endif; ?>

					</div>
					
				</div>
				<div class="name-post">

					<div class="name"><?php echo $people->name; ?></div>
					<div class="post"><?php echo $people->designation ?$people->designation->name:'&nbsp;'; ?></div>
				</div>
				<a href="<?php echo e(request()->headers->get('referer')); ?>" class="pull-right" style="margin-top: 15px;"><i class="fa fa-arrow-left"></i> Back</a>
			</div>
			<div class="detail">
				<div class="detail-group">
					<fieldset>
						<legend>Personal</legend>
						<div class="form-group">
							<label>E-mail</label>
							<div class="input-detail">
								<a href="mailto:<?php echo $people->user->email; ?>"><?php echo $people->user->email; ?></a>
							</div>
						</div>
						<div class="form-group">
							<label>Birthdate</label>
							<div class="input-detail">
								<?php echo $people->dob; ?>

							</div>
						</div>
						<div class="form-group">
							<label>Mobile</label>
							<div class="input-detail">
								<?php echo $people->mobile?$people->mobile:'-'; ?>

							</div>
						</div>
						<div class="form-group">
							<label>Phone</label>
							<div class="input-detail">
								<?php echo $people->phone?$people->phone:'-'; ?>

							</div>
						</div>
						<div class="form-group">
							<label>Gender</label>
							<div class="input-detail">
								<?php echo ucfirst($people->gender?$people->gender:'-'); ?>

							</div>
						</div>
						<div class="form-group">
							<label>Marital status</label>
							<div class="input-detail">
								<?php echo ucfirst($people->marital_status?$people->marital_status:'-'); ?>

							</div>
						</div>
						<?php if(Auth::user()->roles != 'admin'): ?>
							<div class="form-group">
								<label>Department</label>
									<div class="input-detail">
										<?php echo $people->department?$people->department->name:'-'; ?>

									</div>
							</div>
						<?php endif; ?>
					</fieldset>
				</div>
				<div class="detail-group">
					<fieldset>
						<legend>Address</legend>
						<div class="form-group">
							<label>Address</label>
							<div class="input-detail">
								<?php echo ucfirst($people->adrs1?$people->adrs1:''); ?> <?php echo ucfirst($people->adrs2?$people->adrs2:''); ?>

							</div>
						</div>
						<div class="form-group">
							<label>City</label>
							<div class="input-detail">
								<?php echo ucfirst($people->city?$people->city:'-'); ?>

							</div>
						</div>
						<div class="form-group">
							<label>Zipcode</label>
							<div class="input-detail">
								<?php echo ucfirst($people->zipcode?$people->zipcode:'-'); ?>

							</div>
						</div>
						<div class="form-group">
							<label>State</label>
							<div class="input-detail">
								<?php echo ucfirst($people->state?$people->state:'-'); ?>

							</div>
						</div>
						<div class="form-group">
							<label>Country</label>
							<div class="input-detail">
								<?php echo ucfirst($people->country?$people->country:'-'); ?>

							</div>
						</div>
					</fieldset>
				</div>
				<?php if(Auth::user()->roles == 'admin'): ?>
					<?php if(count($educations)>0): ?>
					<div class="detail-group">
						<?php $__currentLoopData = $educations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eduKey=>$education): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<fieldset>
							<legend>Education - <?php echo $eduKey+1; ?></legend>
							<div class="form-group">
								<label>Qualification</label>
								<div class="input-detail">
									<?php echo $education->qualification?$education->qualification:'-'; ?>

								</div>
							</div>
							<div class="form-group">
								<label>College</label>
								<div class="input-detail">
									<?php echo $education->college?$education->college:'-'; ?>

								</div>
							</div>
							<div class="form-group">
								<label>University</label>
								<div class="input-detail">
									<?php echo $education->university?$education->university:'-'; ?>

								</div>
							</div>
							<div class="form-group">
								<label>Passing Year</label>
								<div class="input-detail">
									<?php echo $education->passing_year?$education->passing_year:'-'; ?>

								</div>
							</div>
							<div class="form-group">
								<label>Passing Year</label>
								<div class="input-detail">
									<?php echo $education->percentage?$education->percentage:'-'; ?>

								</div>
							</div>
						</fieldset>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
					<?php endif; ?>
					<?php if(count($experiences)>0): ?>
					<div class="detail-group">
						<?php $__currentLoopData = $experiences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expKey=>$experience): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<fieldset>
							<legend>EXPERIENCE - <?php echo e($expKey+1); ?></legend>
							<div class="form-group">
								<label>Company Name</label>
								<div class="input-detail">
									<?php echo $education->company_name?$education->company_name:'-'; ?>

								</div>
							</div>
							<div class="form-group">
								<label>Experience From</label>
								<div class="input-detail">
									<?php echo $education->from?$education->from:'-'; ?> To <?php echo $education->to?$education->to:'-'; ?>

								</div>
							</div>
							<div class="form-group">
								<label>Salary</label>
								<div class="input-detail">
									<?php echo $education->salary?$education->salary:'-'; ?>

								</div>
							</div>
							<div class="form-group">
								<label>Reason</label>
								<div class="input-detail">
									<?php echo $education->reson?$education->reson:'-'; ?>

								</div>
							</div>
						</fieldset>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
					<?php endif; ?>

					<div class="detail-group">
						<fieldset>
							<legend>Emploment</legend>
							<div class="form-group">
								<label>Pan Number</label>
								<div class="input-detail">
									<?php echo $people->pan_number?$people->pan_number:'-'; ?>

								</div>
							</div>
							<div class="form-group">
								<label>Job Title</label>
								<div class="input-detail">
									<?php echo $people->designation?$people->designation->name:'-'; ?>

								</div>
							</div>
							<div class="form-group">
								<label>Department</label>
								<div class="input-detail">
									<?php echo $people->department?$people->department->name:'-'; ?>

								</div>
							</div>
							<div class="form-group">
								<label>Join Date</label>
								<div class="input-detail">
									<?php echo $people->join_date?$people->join_date:'-'; ?>

								</div>
							</div>
							<div class="form-group">
								<label>Management Level</label>
								<div class="input-detail">
									<?php echo $people->management_level?$people->management_level:'-'; ?>

								</div>
							</div>
						</fieldset>
					</div>
					<div class="detail-group">
						<fieldset>
							<legend>Social</legend>
							<div class="form-group">
								<label>Google</label>
								<div class="input-detail">
									<?php echo $people->google?$people->google:'-'; ?>

								</div>
							</div>
							<div class="form-group">
								<label>Facebook</label>
								<div class="input-detail">
									<?php echo $people->facebook?$people->facebook:'-'; ?>

								</div>
							</div>
							<div class="form-group">
								<label>Linkedin</label>
								<div class="input-detail">
									<?php echo $people->linkedin?$people->linkedin:'-'; ?>

								</div>
							</div>
							<div class="form-group">
								<label>Skype</label>
								<div class="input-detail">
									<?php echo $people->skype?$people->skype:'-'; ?>

								</div>
							</div>
							<div class="form-group">
								<label>Twitter</label>
								<div class="input-detail">
									<?php echo $people->twitter?$people->twitter:'-'; ?>

								</div>
							</div>
						</fieldset>
					</div>
					<div class="detail-group">
						<fieldset>
							<legend>Projects</legend>
							<div class="form-group">
								<label>Current Projects</label>
								<div class="input-detail">
									<span class="currentp"><?php echo e(count($people->user->projects->where('status','active'))); ?></span>
								</div>
							</div>
							<div class="form-group">
								<label>Completed Projects</label>
								<div class="input-detail">
									<span class="completedp"><?php echo e(count($people->user->projects->where('status','completed'))); ?></span>
								</div>
							</div>
						</fieldset>
					</div>
				<?php endif; ?>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<!-- START CONTAINER FLUID -->

  

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/demo/teamwork_7.0/resources/views/peoples/view.blade.php ENDPATH**/ ?>