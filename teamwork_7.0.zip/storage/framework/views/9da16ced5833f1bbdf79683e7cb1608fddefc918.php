<?php $__env->startSection('title','Team'); ?>
<?php $__env->startSection('content'); ?>
<div class="page-user-log">
	<?php echo $__env->make('shared.user_login_detail', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>


<div class="container-fluid">
	<ul class="breadcrumb" ng-cloak>
		<li><a href="<?php echo url('/'); ?>"><span><i class="fa fa-home"></i></span></a></li>

		<li class="active"><span>Teams</span></li>
	</ul>
	<div class="panel panel-transparent">
		<div class="panel-heading clearfix">
			<div class="panel-title">Team Listing</div>
			<div class="action">
				
				<div class="cols">
					<button type='button' data-target="#team-members-modal" data-toggle='modal' class="btn btn-md btn-default"><i class="fa fa-plus"></i> Add Team</button>
				</div>
				
			</div>
		</div>
		<div class="panel-body">
			<div class="loader" ng-if="loading"></div>
			<table class="hover nowrap team-members-box" style="" id="team-members-dt" data-page-length="-1">
				<thead>
					<tr class="heading-bg">
						<th>Department/Team</th>
						
						<th>Member Name</th>
						<th>Action</th>
					</tr>
				</thead>
				
				<tbody>
					<?php $__empty_1 = true; $__currentLoopData = $departmentsList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
						<tr>
							<td><?php echo e(($team->name)); ?></td>
							
							<td>
								<?php $__currentLoopData = $team->teamMembers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$tm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<?php if($tm->member->is_teamlead==true): ?>
										<a href="<?php echo e(url('/people',$tm->member->people->id)); ?>"><span class='btn btn-success'><?php echo e($tm->member->people->name); ?></span></a>
									<?php endif; ?>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<?php
									$cnt = 0;
								?>
								<?php $__currentLoopData = $team->teamMembers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$tm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<?php if($tm->member->is_teamlead==false): ?>
									<a href="<?php echo e(url('/people',$tm->member->people->id)); ?>"><span class='btn btn-warning'><?php echo e($tm->member->people->name); ?></span></a>
										
										<?php if($cnt%3==1): ?>
											<br>
										<?php endif; ?>
										<?php
									$cnt++
									?>
									<?php endif; ?>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</td>
							<td>
								<div class="actions choose-actions">
									<a  data-toggle="modal" class="btn-detail edit btn btn-md btn_edit" data-target="#team-members-modal" data-url="<?php echo route('team-members.edit',[$team->id]); ?>"><i class="fa fa-pencil"></i></a>
									<a class="btn btn-md btn_delete" data-url="<?php echo route('team-members.destroy',[$team->id]); ?>" data-method="delete"><i class="fa fa-trash"></i></a>
								</div>
							</td>
						</tr> 
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
					
					<?php endif; ?> 
				</tbody>
			</table>
		</div>
	</div>

</div>
<div class="modal fade stick-up" id="team-members-modal" tabindex="-1" role="dialog" aria-labelledby="team-members-modal" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header clearfix">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true"><i class="fa fa-close"></i></button>
				<h4 class="team-modal-title">Add Team</h4>
			</div>
			<?php echo Former::Framework('Nude'); ?>

			<?php echo Former::open()->action(URL::route("team-members.store") )->method('post')->enctype("multipart/form-data")->role('form')->id('demo-form2'); ?>

			<?php echo e(csrf_field()); ?>

			<div class="modal-body clearfix"> 
				<div class="col-lg-12">
					<div class="form-group">
						<label>Department/Team<em>*</em></label>
						<?php echo Former::select('department_id')->options([''=>'Select Department']+$departments)->class('form-control  selectpicker')->id('department_id'); ?>

						<span class="department_id_error has-error"></span>
					</div>
				</div>
				<div class="col-lg-12">
					<div class="form-group">
						<label>TeamLead<em>*</em></label>
						<?php echo Former::select('teamlead_id')->options([''=>'Select Team Lead']+$teamLeads)->class('form-control  selectpicker')->id('teamlead_id'); ?>

						<span class="teamlead_id_error has-error"></span>
					</div>
				</div>
				<div class="col-lg-12">
					<div class="form-group">
						<label>Members</label>
						<?php echo Former::select('member_id[]')->options($members1)->class('form-control  selectpicker')->setAttribute('multiple','multiple')->id('member_id'); ?>

						<span class="member_id_error has-error"></span>
					</div>
				</div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-md btn-add btn-crud" >Save</button>   
				
				<button type="button" data-dismiss="modal" class="btn btn-md btn-close" id="close" >Close</button>
			</div>
			<?php echo Former::close(); ?>    
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script type="text/javascript" src='<?php echo e(asset('js/team.js')); ?>'></script>
<script type="text/javascript">
	$(document).ready(function(){
		$('.selectpicker').selectpicker({
			style: 'btn-info',
			size: 4
		});
		$("#team-members-modal").on('hidden.bs.modal', function () {
			$(this).find('form')[0].reset();
		 // jQuery('.selectpicker').selectpicker('render');    
		 $('.modal-backdrop').hide();
		});
		
	// Setup - add a text input to each footer cell

		// DataTable
		var table = $('#team-members-dt').DataTable({
			"displayLength": 100,
			 "search": {
			    "caseInsensitive": false
			  },
		    "lengthMenu": [[25, 50, 75,100, -1], [25, 50, 75,100, "All"]],
		         "paging": true,
			"columnDefs": [
				{ "width": "30%", "targets": 2 },
				{ "orderable": false, "targets": 3 }],
			

		});
	
	});
</script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('styles'); ?>
<style type="text/css">
	.has-error{
		color: red;
	}
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/demo/teamwork_7.0/resources/views/teams/index.blade.php ENDPATH**/ ?>