<nav class="page-sidebar" data-pages="sidebar"  id="leftmenu">
<div class="mCustomScrollbar" data-mcs-theme="minimal-dark" data-height="100%">
	<ul class="task-detail-sidebar">
		<li>
			<label>Task Category</label>
			<span><?php echo $task_details->category->name or '-'; ?></span>
		</li>
		<li>
			<label>Assigned to</label>
			<?php $__empty_1 = true; $__currentLoopData = $task_details->users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php if($tu->id != 0): ?>
				    <span> <?php echo $tu->people->fname." ".$tu->people->lname; ?></span>
                <?php else: ?>
                    Anyone
                <?php endif; ?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
				<span>  Anyone</span>
			<?php endif; ?>
		</li>
		<li>
			<label>Start date</label>
			<span>
            
            <?php echo $task_details->start_date or '-'; ?>

			
            
			</span>


		</li>
		<li>
			<label>Due date</label>
			<span><?php echo $task_details->due_date or '-'; ?></span>
		</li>
		<li>
			<label>Assigned by</label>
			<span><?php echo $task_details->assignedby or '-'; ?></span>
		</li>
		<li>
			<label>Date assigned</label>
			<span><?php echo $task_details->created_at->format('D d M Y h:i A'); ?></span>
		</li>
		<li>
			<label>Date updated</label>
			<span><?php echo $task_details->updated_at->format('D d M Y h:i A'); ?></span>
		</li>
		<li>
			<label>Task Id</label>
			<span># <?php echo $task_details->id; ?></span>
		</li>
	</ul>
</div>
</nav><?php /**PATH /var/www/html/demo/teamwork_7.0/resources/views/shared/task_detail_sidebar.blade.php ENDPATH**/ ?>