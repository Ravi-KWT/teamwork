<table>
    <thead>
    <tr>
        <th><b>Date</b></th>
        <th><b>LoggedBy</b></th>
        <th><b>Project Name</b></th>
        <th><b>Company</b></th>
        <th><b>Log Description</b></th>
        <th><b>Tasklist</b></th>
        <th><b>Task Name</b></th>
        <th><b>Start Time</b></th>
        <th><b>End Time</b></th>
        <th><b>Billable</b></th>
        <th><b>Hours</b></th>
        <th><b>Minutes</b></th>
        <th><b>Decimal Hours</b></th>
    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($log[0]); ?></td>
            <td><?php echo e($log[1]); ?></td>
            <td><?php echo e($log[2]); ?></td>
            <td><?php echo e($log[3]); ?></td>
            <td><?php echo e($log[4]); ?></td>
            <td><?php echo e($log[5]); ?></td>
            <td><?php echo e($log[6]); ?></td>
            <td><?php echo e($log[7]); ?></td>
            <td><?php echo e($log[8]); ?></td>
            <td><?php echo e($log[9]); ?></td>
            <td><?php echo e($log[10]); ?></td>
            <td><?php echo e($log[11]); ?></td>
            <td><?php echo e($log[12]); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH /var/www/html/demo/teamwork_7.0/resources/views/exports/logs.blade.php ENDPATH**/ ?>