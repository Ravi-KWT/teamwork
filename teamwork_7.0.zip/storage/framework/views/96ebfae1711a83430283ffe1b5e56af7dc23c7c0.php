<?php $__env->startSection('title','Change Password'); ?>
<?php $__env->startSection('content'); ?>
<div class="login_page change_profile_page">
    <div class="container">
        <div class="form-group">
            <div class="logo">
                <img src="<?php echo e(asset('img/logo.png')); ?>" alt="logo" data-src="<?php echo e(asset('img/logo.png')); ?>" data-src-retina="<?php echo e(asset('img/img/logo_2x.png')); ?>" width="300">
            </div>
        </div>
        <div class="form-group text-center">
            <p>Change Profile</p>
        </div>
        <div class="row">
          <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
          <?php if(auth()->user()->people->photo): ?>
            <div class="user_profile_pic">
                <div class="wraps">
                    <img src="<?php echo e(auth()->user()->people->photo_url('medium')); ?>" alt="profile pic">
                  
                    <div id='select-pic-container'>
                        <div class="change-pic" id='select-pic'>
                             <a htef='javascript:;' >Change Photo<i class="fa fa-camera"></i></a>
                        </div>
                    </div>
                </div>
                <div class='notice'>*Upload Only JPG,PNG,JPEG</div>
                <div class="fileextensionerror" id='console'></div>
            </div>
          <?php else: ?>
            <div class="user_profile_pic">
                <div class="wraps">
                  <img src="<?php echo e(asset('img/user-profile.png')); ?>" alt="profile pic">

                  <div id='select-pic-container'>
                        <div class="change-pic" id='select-pic'>
                             <a htef='javascript:;' >Change Photo<i class="fa fa-camera"></i></a>
                        </div>
                    </div>
                </div>
                <div class='notice'>*Upload only jpg,png </div>
                <div  id="console" class="fileextensionerror"> </div>
            </div>
          <?php endif; ?>
          </div>
          <div class="loader" style="display:none;"></div>
          <div class="col-lg-9 col-md-9 col-sm-9 col-xs-12">
            <?php
            $marital_statuses = array('maried'=>'maried',
                'single'=>'single',
                'other'=>'other');
            ?>
            <?php echo Former::framework('Nude'); ?>

            <?php echo $__env->make('shared.session', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo Former::open()->method('post')->action( url('change-profile'))->class('form')->role('form')->token(); ?>

            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                    <div class="form-group">
                        <?php echo Former::label('First Name')->class('label'); ?>

                        <?php echo Former::text('fname')->placeholder('first name')->id(false)->label(false)->class('form-control'); ?>

                        <?php if($errors->has('fname')): ?>
                          <span class="error">
                            <strong><?php echo e($errors->first('fname')); ?></strong>
                          </span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                    <div class="form-group">
                        <?php echo Former::label('Last Name')->class('label'); ?>

                        <?php echo Former::text('lname')->placeholder('last name')->id(false)->label(false)->class('form-control'); ?>

                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                    <div class="form-group">
                        <?php echo Former::label('Phone')->class('label'); ?>

                        <?php echo Former::text('phone')->placeholder('phone')->id(false)->label(false)->class('form-control'); ?>

                        <?php if($errors->has('phone')): ?>
                          <span class="error">
                            <strong><?php echo e($errors->first('phone')); ?></strong>
                          </span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                    <div class="form-group">
                        <?php echo Former::label('Mobile')->class('label'); ?>

                        <?php echo Former::text('mobile')->placeholder('mobile')->id(false)->label(false)->class('form-control'); ?>

                        <?php if($errors->has('mobile')): ?>
                          <span class="error">
                            <strong><?php echo e($errors->first('mobile')); ?></strong>
                          </span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                    <div class="form-group">
                        <?php echo Former::label('Google')->class('label'); ?>

                        <?php echo Former::text('google')->placeholder('google')->id(false)->label(false)->class('form-control'); ?>

                        <?php if($errors->has('google')): ?>
                          <span class="error">
                            <strong><?php echo e($errors->first('google')); ?></strong>
                          </span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                    <div class="form-group">
                        <?php echo Former::label('Facebook')->class('label'); ?>

                        <?php echo Former::text('facebook')->placeholder('facebook')->id(false)->label(false)->class('form-control'); ?>

                         <?php if($errors->has('facebook')): ?>
                          <span class="error">
                            <strong><?php echo e($errors->first('facebook')); ?></strong>
                          </span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                    <div class="form-group">
                        <?php echo Former::label('Website')->class('label'); ?>

                        <?php echo Former::text('website')->placeholder('website')->id(false)->label(false)->class('form-control'); ?>

                        <?php if($errors->has('website')): ?>
                            <span class="error">
                            <strong><?php echo e($errors->first('website')); ?></strong>
                          </span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                    <div class="form-group">
                        <?php echo Former::label('LinkedIn')->class('label'); ?>

                        <?php echo Former::text('linkedin')->placeholder('linkedin')->id(false)->label(false)->class('form-control'); ?>

                          <?php if($errors->has('linkedin')): ?>
                            <span class="error">
                            <strong><?php echo e($errors->first('linkedin')); ?></strong>
                          </span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                    <div class="form-group">
                        <?php echo Former::label('Skype')->class('label'); ?>

                        <?php echo Former::text('skype')->placeholder('skype')->id(false)->label(false)->class('form-control'); ?>

                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                    <div class="form-group">
                        <?php echo Former::label('Twitter')->class('label'); ?>

                        <?php echo Former::text('twitter')->placeholder('twitter')->id(false)->label(false)->class('form-control'); ?>

                          <?php if($errors->has('twitter')): ?>
                            <span class="error">
                            <strong><?php echo e($errors->first('twitter')); ?></strong>
                          </span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="form-group">
                        <?php echo Former::submit('Update')->class('btn btn-md btn-default'); ?>

                       
                        <a href="<?php echo e(url()->previous()); ?>" class="btn btn-md btn-default">Back</a>
                    </div>
                </div>
            </div>
            <?php echo Former::close(); ?>

          </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

<?php $__env->startSection('scripts'); ?>

<script type="text/javascript">
    $(document).ready(function() {
//START CROP WITH PLUPLOAD
var uploader = new plupload.Uploader({
      runtimes : 'html5,flash,silverlight,html4',
      rename : true,
      browse_button : "select-pic",
      container: document.getElementById('select-pic-container'),
      url : "<?php echo asset('/plupload/upload.php'); ?>",

      filters: {
          mime_types : [
            { title : "Image files", extensions : "jpg,png,jpeg" }

          ],
          max_file_size: "20mb"
    },
      multi_selection:false,
      // Flash settings
      flash_swf_url : "<?php echo asset('/plupload/Moxie.swf'); ?>",
      // Silverlight settings
      silverlight_xap_url : "<?php echo asset('/plupload/Moxie.xap'); ?>",

      init: {
            PostInit: function() {
            },

            FilesAdded: function(up, files) {
                $(".loader").show();
                files[0].name = "<?php echo e(uniqid()); ?>_"+files[0].name;
                uploader.start();
            },

            FileUploaded: function(up,file)
            {
                    var post={};
                    post.photo=file.name;
                    var url ='/update-user-profile-photo';

                   $.ajax({
                   type: "POST",
                   url: url,
                   data: post,
                   cache: false,
                   success: function(data){
                        $(".loader").hide();
                        window.location.reload();
                    }

            });

            },
            Error: function(up, err) {
                document.getElementById('console').innerHTML = "<span>\nError #" + err.message+"</span>";
                $(".loader").hide();
            }
            }
      });
      uploader.init();

  });
//END CROP WITH PLUPLOAD
</script>
<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.change_profile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/demo/teamwork_7.0/resources/views/auth/change-profile.blade.php ENDPATH**/ ?>