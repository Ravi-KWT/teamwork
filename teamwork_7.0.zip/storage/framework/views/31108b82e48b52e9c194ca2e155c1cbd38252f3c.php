<?php $__env->startSection('title','404'); ?>
<?php $__env->startSection('content'); ?>
<div class="page_404">
  <div class="wrap">
    <h1>404</h1>
    <h2>Sorry but we couldnt find this page</h2>
    <p>This page you are looking for does not exsist <a href="<?php echo url('/'); ?>">Back</a></p>
  </div>
  <div class="bg">
    <img src="<?php echo asset('img/demo/team2.jpg'); ?>" data-src="<?php echo asset('img/demo/team2.jpg'); ?>" data-src-retina="<?php echo asset('img/demo/team2.jpg'); ?>" alt="" class="lazy">
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.register', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/demo/teamwork_7.0/resources/views/errors/404.blade.php ENDPATH**/ ?>