<?php $__env->startSection('title','Dashboard'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('shared.session', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="page-user-log ">
	<?php echo $__env->make('shared.user_login_detail', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<div class="home_page">
	<div class="container-fluid">
		<div class="employee_project_clients mb_30">
			<div class="row">
			<?php if(Auth::user()->roles == 'admin'): ?>
				<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
					<div class="our-employee box">
						<span class="icons"><img src="<?php echo asset('img/employe-icon.png'); ?>" alt=""></span>
						<span class="count employee"><?php echo e(DB::table('users')->where('id','!=', 0)->count()); ?></span>
						<span class="title"><a class="employee" href='<?php echo url('people'); ?>' >Our People</a></span>
					</div>
				</div>
				<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
					<div class="our-projects box">
						<span class="icons"><img src="<?php echo asset('img/projects-icon.png'); ?>" alt=""></span>
						<?php if(Auth::user()->roles =='admin'): ?>
						<span class="count projects"><?php echo DB::table('projects')->where('status','active')->count(); ?></span>
						<?php else: ?>
							<span class="count projects"><?php echo e(count(Auth::user()->projects->where('status','active'))); ?></span>
						<?php endif; ?>
						<span class="title"><a class="projects" href='<?php echo url('projects'); ?>' >Current Projects</a></span>
					</div>
				</div>

					<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
						<div class="our-clients box">
							<span class="icons"><img src="<?php echo asset('img/client-icon.png'); ?>" alt=""></span>
							<span class="count clients"><?php echo DB::table('companies')->count(); ?></span>
							<span class="title"><a class="clients" href='<?php echo url('companies'); ?>'>Our Clients</a></span>
						</div>
					</div>
				<?php else: ?>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
						<div class="our-employee box">
							<span class="icons"><img src="<?php echo asset('img/employe-icon.png'); ?>" alt=""></span>
							<span class="count employee"><?php echo e(DB::table('users')->where('id','!=', 0)->count()); ?></span>
							<span class="title"><a class="employee" href='<?php echo url('people'); ?>' >Our People</a></span>
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
						<div class="our-projects box">
							<span class="icons"><img src="<?php echo asset('img/projects-icon.png'); ?>" alt=""></span>
							<?php if(Auth::user()->roles =='admin'): ?>
							<span class="count projects"><?php echo DB::table('projects')->where('status','active')->count(); ?></span>
							<?php else: ?>
								<span class="count projects"><?php echo e(count(Auth::user()->projects->where('status','active'))); ?></span>
							<?php endif; ?>
							<span class="title"><a class="projects" href='<?php echo url('projects'); ?>' >Current Projects</a></span>
						</div>
					</div>
				<?php endif; ?>
			</div>
		</div>
		<div class="latest-task">
			<div class="panel panel-transparent">
				<div class="panel-heading clearfix">
					<div class="panel-title">Latest Task</div>
				</div>
				<div class="panel-body">
					<?php if($tasks->count()>0): ?>
					<table id="user-log-dt" data-paging-type='simple_numbers' ng-cloak cellspacing="0" cellpadding="0" class="user-log-dt" style="width:100%">
						<thead>
							<tr>
								<th>Date</th>
								<th class="text-left">Name</th>
								<th>Project</th>
								<th>Assign To</th>
							</tr>
						</thead>
						
						<tbody>
							<?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td>
									<?php if($task->created_at): ?>
									<?php echo $task->created_at->format('d/m/Y'); ?>

									<?php endif; ?>
								</td>
								<td class="text-left">
									
									<?php echo $task->name; ?>

								</td>
								<td>
									
									<?php echo $task->project->name or ''; ?>

								</td>
								<td>
									<?php $__empty_1 = true; $__currentLoopData = $task->users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
									<?php if($user->id == 0): ?>
									Anyone
									<?php else: ?>
									<a href="<?php echo e(url('/people',$user->people->id)); ?>"> <?php echo $user->people->name or '-'; ?><?php echo count($task->users) > 1 ? ',' : ''; ?></a>
									<?php endif; ?>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
									Anyone
									<?php endif; ?>
								</td>
							</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>
					<?php else: ?>
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
						<div style="text-align:center;">
							<img src="<?php echo asset('img/noTasks.png'); ?>"  height="100px" width="100px" />
							<p><h3>No Records</h3></p>
						</div>
					</div>
					<?php endif; ?>
				</div>
			</div>
		</div>
	</div>
</div>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script type="text/javascript" src="//cdn.datatables.net/plug-ins/1.10.16/sorting/date-uk.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/responsive/2.2.3/js/dataTables.responsive.min.js"></script>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/responsive/2.1.0/css/responsive.dataTables.min.css">
	<script type="text/javascript">
	$(document).ready(function(){
	
		$('.user-log-dt').DataTable({
			responsive: true,
          	columnDefs: [
		       { type: 'date-uk', targets: 0 }
		    ],
		    oLanguage: {
		        oPaginate: {
			        sNext: '<span class="pagination-fa"><i class="fa fa-chevron-right" ></i></span>',
			        sPrevious: '<span class="pagination-fa"><i class="fa fa-chevron-left" ></i></span>'
			    }
    		}
		});
		// $('#user-log-dt tfoot th').each( function () {
		// 	var title = $(this).text();
		// 	if(title!='Action'){
		// 		$(this).html( '<input type="text" placeholder="Search '+title+'" />' );
		// 	}
		// } );
		// 	// DataTable
		// 	var table = $('#user-log-dt').DataTable({
		// 		responsive: true,
  //             	columnDefs: [
		// 	       { type: 'date-uk', targets: 0 }
		// 	    ]
		// 	});
		// 	// Apply the search
		// 	table.columns().every( function () {
		// 		var that = this;
		// 		$( 'input', this.footer() ).on( 'keyup change', function () {
		// 			if ( that.search() !== this.value ) {
		// 				that
		// 				.search( this.value )
		// 				.draw();
		// 			}
		// 		} );
		// 	} );
		});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/demo/teamwork_7.0/resources/views/welcome.blade.php ENDPATH**/ ?>