<?php $__env->startSection('title','Resource Avaibility'); ?>
<?php $__env->startSection('content'); ?>
<div ng-controller="ResourceCtrl" >
	<div class="page-user-log">
		<?php echo $__env->make('shared.user_login_detail', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</div>
	<style type="text/css">
		#team-members-dt_wrapper{
			margin-top: 30px;
		}
		#team-members-dt_wrapper th span:before{
			width: 0;
			border:0; 
		}
		.resource-list{

			background: #e8eaea;
			margin-bottom: 10px;
			padding-top: 10px;
		}
		.multiselect-container>li>a>label>input[type=checkbox] {
		margin-bottom: 3px;
		border: 1px solid #000;
		opacity: 1;
		position: relative;
		margin-right: 5px;
		visibility: visible;
		}
		.multiselect-container>li.active a .checkbox {
		color: #ffffff;
		}
	</style>
	 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.13/css/bootstrap-multiselect.css" />
	<div class="container-fluid">
		<?php echo $__env->make('shared.session', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<div class="panel panel-transparent">
			<div class="panel-heading clearfix">
				<div class="panel-title">Resources Listing</div>
			</div>
			<div class="panel-body">
				     <?php echo $__env->make('shared.session', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  
				    
                  <div class="filtter clearfix">
                    <div class="container-fluid">
                        <div class="row" >
                            <form name='searchEverythingTask' action="<?php echo route('filter-resource-availability'); ?>" method="get" class='form' role='form'>
                                <div class="col-lg-10 col-md-10 col-sm-10 col-xs-12">
                                    <div class="form-inline">
                                       <?php if(Auth::user()->roles=='admin'): ?>
                                        <div class="form-group" ng-cloak>
                                            <label class="label"><span>Users</span></label>
                                             <?php echo Former::select("user_id","")->options($users ); ?>

                                        </div>
                                        <?php endif; ?>
                                        <div class="form-group">
                                            <div class="form-group" >
                                                <label class="label"><span>Date Range</span></label>
                                                <div class="input-group datepicker"  date-set=
                                                <?php if(isset($start_date)): ?>
                                                   <?php echo $start_date; ?>

                                                <?php else: ?>
                                                    <?php echo Carbon\Carbon::now()->subdays(2); ?>

                                                <?php endif; ?>
                                                date-format="dd-MM-yyyy" 
                                                    selector="form-control">
                                                    <input type="text" name="start_date" class="form-control" placeholder="Pick a start date" id="searchForm-start-date">
                                                    <label class="input-group-addon" for="searchForm-start-date">
                                                        <i class="fa fa-calendar"></i>
                                                    </label>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                               <i class="fa fa-arrows-h"></i>
                                            </div>
                                            <div class="form-group">
                                                <div class="input-group datepicker" date-set=
                                                <?php if(isset($end_date)): ?>
                                                   <?php echo $end_date or ''; ?>

                                                <?php else: ?>
                                                    <?php echo Carbon\Carbon::now(); ?>

                                                <?php endif; ?> date-format="dd-MM-yyyy"  selector="form-control">
                                                    <input type="text"  name="end_date" class="form-control" placeholder="Pick a end date" id="searchForm-end-date">
                                                    <label class="input-group-addon" for="searchForm-end-date">
                                                        <i class="fa fa-calendar"></i>
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="label"><span>TeamLead</span></label>
                                            <?php echo Former::select("teamlead_id","")->options($teamleads); ?>

                                        </div>
                                      

                                    </div>
                                </div>
                                <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
                                    <ul class="list-inline">
                                        <li>
                                        <div class="form-group">
                                            <label class="label">&nbsp;</label>
                                            <input type="submit" name='filter' value="Filter" class="btn btn-md btn-default">
                                        </div>
                                        </li>
                                       
	                                        <li>
	                                            <div class="form-group">
	                                                <label class="label">&nbsp;</label>
	                                                <div class="dropdown drop-arrow rightside padd">
	                                                    <button class="btn btn-md btn-default" type="button" id="export" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
	                                                          Export
	                                                         <span class="caret"></span>
	                                                    </button>
	                                                    <ul class="dropdown-menu" aria-labelledby="export">
	                                                        <li>
	                                                            <button  class="btn-block btn btn-sm btn-default" type="submit" name="excel" value="Excel">Excel</button>
	                                                        </li>
	                                                    </ul>
	                                                </div>
	                                            </div>
	                                        </li>
                                        
                                    </ul>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

				 <?php if($workloads->count() > 0): ?>
					<table id="team-members-dt" class="table vc" ng-cloak>
						<thead>
							<tr>
								<th>Date</th>
								<th>Resource Name</th>
								<th>TeamLead</th>
								<th>Work Load</th>
								<th>Projects</th>
								<th>Others</th>
								<th>On Leave</th>
							</tr>    
						</thead>
						
						<tbody>
							<?php $__empty_1 = true; $__currentLoopData = $workloads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $workload): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
								<tr>
									<td><?php echo e($workload->date); ?></td>
									<td><a href="<?php echo e(url('/people',$workload->user->people->id)); ?>"> <?php echo e($workload->user->people->name); ?></a></td>
									<td ng-cloak><a href="<?php echo e(url('/people',$workload->teamlead->people->id)); ?>" style="text-transform: uppercase;"><?php echo e($workload->teamlead->people->name); ?></a></td>
									<td>
										<div class="row" >
											<div class="col-sm-6" ng-cloak>
												<input type="text" class='employee-daily-workload' name="members-slider" data-id="<?php echo e($workload->id); ?>" 
												data-teamlead-id="<?php echo e($workload->teamlead_id); ?>" 
												data-member-id="<?php echo e($workload->member_id); ?>" 
												data-provide="slider" slider-min="0" data-slider-max="100" data-slider-step="1"  data-slider-tooltip="show" data-slider-value="<?php echo e($workload->work_load); ?>" data-slider-enabled="false" >
											</div>
											<div class="col-sm-6" >
												<span class="workload_label"><?php echo e($workload->work_load); ?> %</span>
											</div>
										</div>
									</td>
									<td style="width: 150px; word-break: keep-all;"><?php echo e($workload->projects); ?></td>
									<td style="width: 150px; word-break: keep-all;"><?php echo e($workload->others); ?></td>
									<td><?php echo e($workload->on_leave ?ucwords(str_replace('_', ' ', $workload->on_leave)):''); ?></td>
								</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

							<?php endif; ?>
						</tbody>
					</table>
				<?php else: ?>
				<br>&nbsp;<br>
					<div class="col-md-12">
						<div style="text-align:center;">
							<img src="<?php echo asset('img/noMilestone1.png'); ?>"  height="100px" width="100px" />
							<h3 ng-cloak>No Record Found</h3>
						</div>
					</div>
				<?php endif; ?>
			</div>
		</div>
	</div>
	
		
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.13/js/bootstrap-multiselect.js"></script>
<script src="https://js.pusher.com/3.1/pusher.min.js"></script>
<script type="text/javascript">
	$(function() {
	    $('.projects').multiselect({
	      nonSelectedText: 'Select Project',
	      enableFiltering: true,
	      enableCaseInsensitiveFiltering: true,
	      
	     });
	});
	var pusher = new Pusher('7e33696f1827248f3d59', {
		cluster: 'ap2',
		forceTLS: true
	});

	var channel = pusher.subscribe('user-availability');
	var user = <?php echo Auth::user(); ?>;
	channel.bind('App\\Events\\UserAvailability', function(data) {
		if(user.roles == "admin" || (user.roles  == 'employee' && user.is_teamlead == true)){
			this.getAvailableUsers(data.status);
		}
	});
	function getAvailableUsers(status){
		var status = status;
		$.get('<?php echo route("get-available-users"); ?>',{status:status},function(response){
			$('#available-user').html(response);
		});
	}
	jQuery(document).ready(function($){
		jQuery('#team-members-dt tfoot th').each( function () {
			var title = jQuery(this).text();
			if(title!='Action'){
				jQuery(this).html( '<input type="text" placeholder="Search '+title+'" />' );
			}
		} );

		var table = $('#team-members-dt').DataTable({
			"columnDefs": [
			{ "visible": false, "targets": 2 },
			{ "orderable": false, "targets": 1 },
			{ "orderable": false, "targets": 0 },
			{ "orderable": false, "targets": 3 },
			{ "orderable": false, "targets": 4 },
			],
			"order": [[ 2, 'asc' ],[ 0, 'desc' ],[ 1, 'asc' ]],
			"displayLength": 100,
			"lengthMenu": [[25, 50, 75,100, -1], [25, 50, 75,100, "All"]],
			"paging": true,
			"drawCallback": function ( settings ) {
				var api = this.api();
				var rows = api.rows( {page:'current'} ).nodes();
				var last=null;
				
				api.column(2,{page:'current'} ).data().each( function ( group, i ) {

					if ( last !== group ) {

						$(rows).eq( i ).before(
							'<tr class="group"><td colspan="5">Team lead : '+group+'</td></tr>'
							);
						last = group;
					}
				} );
			}
		} );
		
		    // Order by the grouping
		    $('#team-members-dt tbody').on( 'click', 'tr.group', function () {
		    	var currentOrder = table.order()[0];
		    	if ( currentOrder[0] === 2 && currentOrder[1] === 'asc' ) {
		    		table.order( [ 2, 'desc' ] ).draw();
		    	}
		    	else {
		    		table.order( [ 2, 'asc' ] ).draw();
		    	}
		    } );

		});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/demo/teamwork_7.0/resources/views/resources/summary.blade.php ENDPATH**/ ?>