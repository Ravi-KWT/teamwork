<?php $__env->startSection('title','Projects'); ?>
<?php $__env->startSection('content'); ?>
<div ng-controller="ResourceCtrl" >
	<div class="page-user-log">
		<?php echo $__env->make('shared.user_login_detail', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</div>
	<style type="text/css">
		#team-members-dt_wrapper{
			margin-top: 30px;
		}
		#team-members-dt_wrapper th span:before{
			width: 0;
			border:0; 
		}
		div.dt-buttons{
			margin-left: 15px;
		}
		div.dt-buttons .dt-button{
			padding: 5px 10px;
		}	
	</style>
	<ul class="nav nav-tabs clearfix">
         <li ><a href="<?php echo e(url('projects')); ?>">Current Projects</a></li>
        <li class="active"><a href="<?php echo route('projects-list',['archive']); ?>">Archived Projects</a></li>
        <li ><a href="<?php echo route('projects-list',['completed']); ?>">Completed Projects</a></li>
         <li ><a href="<?php echo route('projects-list',['onhold']); ?>">On Hold Projects</a></li>
    </ul>

	<div class="container-fluid">
		<?php echo $__env->make('shared.session', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<div class="panel panel-transparent">
			<div class="panel-heading clearfix">
				<div class="panel-title">Projects Listing</div>
			</div>
			<div class="panel-body">
				<?php echo $__env->make('shared.session', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  
					<table id="team-members-dt" class="table vc">
						<thead>
							<tr>
								<th class="datatable-nosort">Name</th>
								<th class="datatable-nosort">Client</th>
								<th class="datatable-nosort">Status</th>
								<th class="datatable-nosort">Action</th>
							</tr>    
						</thead>
						<tbody>
							<?php $__empty_1 = true; $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
								<tr>
									<td><a href="<?php echo e(url('projects/'.$project->id.'/tasks')); ?>"><?php echo e($project->name); ?></a></td>
									<td><?php echo e($project->company->name); ?></td>
									<td><?php echo e($project->status); ?></td>
									<td><?php echo Former::select("status",'')->options([""=>'Change Status','active'=>'Active','onhold'=>'On Hold','completed'=>'Completed'])->id($project->id)->class('change-project-status form-control'); ?></td>
								</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

							<?php endif; ?>
						</tbody>
					</table>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">
	$(document).ready(function(){
		var table = $('#team-members-dt').DataTable({
		        "columnDefs": [
		            { "visible": false, "targets": 1 },
	
					{
						targets: "datatable-nosort",
						orderable: false,
					}

		        ],
		        "processing": true,
			    "dom": 'lBfrtip',
				"buttons": [
		            {
		                extend: 'collection',
		                text: ' Export',
		                buttons: [
		                    'copy',
		                    'excel',
		                    'csv',
		                    'pdf',
		                    'print'
		                ]
		            }
			    ],
		        "order": [[ 1, 'asc' ],[ 0, 'asc' ]],
		        "paging": true,
		        "drawCallback": function ( settings ) {
		            var api = this.api();
		            var rows = api.rows( {page:'current'} ).nodes();
		            var last=null;
		 
		            api.column(1, {page:'current'} ).data().each( function ( group, i ) {
		                if ( last !== group ) {
		                    $(rows).eq( i ).before(
		                        '<tr class="group"><td colspan="5">Client : '+group+'</td></tr>'
		                    );
		                    last = group;
		                }
		            } );
		        }
		    } );
		
	$(document).on('change','.change-project-status',function(e){
			var id = $(this).attr('id');
			var status = $(this).val();
			e.preventDefault();
			$.ajaxSetup({
				headers: {
					'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
				}
			});
			url = "<?php echo e(route('change-project-status')); ?>";
			$.ajax({
				url: url,
				type: 'POST',
				data: {   
					id: id,
					status:status
				},
				success: function(data) {
					if(data.success == true){
						alert('Status changed successfully ');
						window.location.reload();
					}
				}
			});
		});
	});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/demo/teamwork_7.0/resources/views/projects/archive.blade.php ENDPATH**/ ?>