<?php $__env->startSection('title','Change Password'); ?>
<?php $__env->startSection('content'); ?>
<div class="login_page change_pass container-fluid">
  
        <div class="col-lg-4 col-center">
          <div class="login_form">
            
            
            <?php echo Former::framework('Nude'); ?>

            <?php echo $__env->make('shared.session', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo Former::open()->method('post')->action( url('change-password'))->class('form')->role('form')->token(); ?>

            <div class="form-group">
              <?php echo Former::label('Current Password')->class('label'); ?>

              <?php echo Former::password('oldpassword')->placeholder('Current Password')->id(false)->label(false)->class('form-control required'); ?>

              <?php if($errors->has('oldpassword')): ?>
              <span class="error">
                <strong><?php echo e($errors->first('oldpassword')); ?></strong>
              </span>
              <?php endif; ?>
            </div>
            <div class="form-group">
              <?php echo Former::label('New Password')->class('label'); ?>

              <?php echo Former::password('newpassword')->placeholder('New Password')->id(false)->label(false)->class('form-control required'); ?>

              <?php if($errors->has('newpassword')): ?>
              <span class="error">
                <strong><?php echo e($errors->first('newpassword')); ?></strong>
              </span>
              <?php endif; ?>
            </div>
            <div class="form-group">
              <?php echo Former::label('Confirm Password')->class('label'); ?>

              <?php echo Former::password('password_confirmation')->id(false)->placeholder('Confirm Password')->label(false)->class('form-control required'); ?>

              <?php if($errors->has('password_confirmation')): ?>
              <span class="error">
                <strong><?php echo e($errors->first('password_confirmation')); ?></strong>
              </span>
              <?php endif; ?>
            </div>
           
            <?php echo Former::submit('Change Password')->class('btn btn-md btn-default'); ?>

             
             <a href="<?php echo e(url()->previous()); ?>" class="btn btn-md btn-default">Back</a>
            <?php echo Former::close(); ?>

          </div>
        </div>
      </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/demo/teamwork_7.0/resources/views/change-password.blade.php ENDPATH**/ ?>