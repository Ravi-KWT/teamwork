<nav class="page-sidebar" data-pages="sidebar" id="leftmenu">
<div class="mCustomScrollbar" data-mcs-theme="minimal-dark" data-height="100%">
    <?php if(count($projects) > 0): ?>
      <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($company->id == $key): ?>
                    <div class="panel">
                        <div class="panel-heading">
                            <span class="title"><?php echo $company->name; ?></span>
                            <span class="badge">
                                <?php echo $project->count(); ?>

                            </span>
                        </div>
                        <div class="panel-body">
                        <ul>
                            <?php $__currentLoopData = $project; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><a href="<?php echo url('/projects',array('id'=>$p->id)),'/','tasks'; ?>"><?php echo ucwords($p->name); ?></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <?php if(Auth::user()->roles == 'admin'): ?>
            <p>No projects</p>
        <?php else: ?>
            <p>No project allocated to you</p>
        <?php endif; ?>
    <?php endif; ?>
</div>
</nav><?php /**PATH /var/www/html/demo/teamwork_7.0/resources/views/shared/company_list.blade.php ENDPATH**/ ?>