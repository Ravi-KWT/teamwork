<nav class="page-sidebar" data-pages="sidebar" id="leftmenu">
<div class="mCustomScrollbar" data-mcs-theme="minimal-dark" data-height="100%">
<div class="panel">
  <div class="panel-heading"><a href="#">Categories</a></div>
  <div class="panel-body">
          <ul>
            <?php 
            // dd($projectsCategories);
                asort($project_categories);
            ?>
            <?php $__empty_1 = true; $__currentLoopData = $project_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php
                    $count = 0;
                    foreach($projects as $project)
                    {
                        if (!empty($project->category_id)) {
                            if($project->category_id == $key)
                            {
                                $count++;
                            }
                        }
                    }
                ?>
                 <li >
                    <a href="<?php echo url('/project-categories',$key); ?>"><?php echo $category; ?>

                    <span class="badge"><?php echo e($count); ?></span>
                    </a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
               No Category
            <?php endif; ?>
        </ul>

	</div>
</div>
</div>
</nav><?php /**PATH /var/www/html/demo/teamwork_7.0/resources/views/shared/project_list.blade.php ENDPATH**/ ?>