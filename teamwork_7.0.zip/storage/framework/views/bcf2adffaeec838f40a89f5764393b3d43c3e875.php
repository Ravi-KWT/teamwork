<?php if(Auth::user()->timers->where('completed',false)->count() > 0): ?>
	<div class="tl-header">
		<div class="tl-count-item"><?php echo e(Auth::user()->timers->count()); ?> Active Timers</div>
		<?php if(Auth::user()->timers->count() > 1): ?>
			<div class="tl-item-toggle">
				<a href="javascript:;" id="current-timer-show" data-type="down"><i class="fa fa-angle-down"></i></a>
			</div>
		<?php endif; ?>
	</div>
	<?php $__currentLoopData = Auth::user()->timers->sortByDesc('running'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $timer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	
	<div class="log log-item">
				<div class="time-log-view-header">
					<div class="time-log-title">
						<div class="tl-project-name"><?php echo e($timer->task->project->name); ?></div>
						<div class="tl-project-task-name"><?php echo e($timer->task->name); ?></div>
						<a class="tl-comment-trigger addition-timer-data-show" data-toggle="collapse"  data-timer-id="<?php echo e($timer->id); ?>" >
							<i class="fa fa-angle-down"></i>
						</a>
					</div>
					<div class="log-actions">
						<div class="tl-time timer-counter-<?php echo e($timer->id); ?>"><?php if($timer->running == 0): ?> <?php echo e(gmdate("H:i:s", $timer->duration)); ?> <?php endif; ?></div>
						<div class="tl-actions">
							<button class="tl-action-btn resume-timer" data-timer-id="<?php echo e($timer->id); ?>" <?php if($timer->running == 1): ?> style="display: none;" <?php endif; ?>> <i class="fa fa-play"></i> Start</button>
							<button class="tl-action-btn pause-timer" data-timer-id="<?php echo e($timer->id); ?>" <?php if($timer->running == 0): ?> style="display: none;" <?php endif; ?>><i class="fa fa-pause"></i> Pause</button>
							<button class="tl-action-btn btn-success submit-log-timer" data-timer-id="<?php echo e($timer->id); ?>"><i class="fa fa-clock-o"></i> Log</button>
						</div>
					</div>
				</div>
				<div class="tl-comment">
					<div class="collapse addition-timer-data" id="collapseExample<?php echo e($timer->id); ?>" style="display: none;">
						<div class="form-group">
							<label for="description">Description</label>
							<textarea name="description" class="description form-control"></textarea>
						</div>
						<div class="tl-comment-action">
							<div class="tl-billable-check">
								<div >
									<label class="switch small-switch">
										<input type="checkbox" name="billable" class="billable" checked>
										<span class="slider round"></span>
									</label>
								</div>
								<label>Billable</label>
							</div>
							<div class="tl-delete-log">
								<button class="tl-action-btn btn-danger delete-log" data-timer-id="<?php echo e($timer->id); ?>"> <i class="fa fa-times"></i>Delete</button>
							</div>
						</div>
					</div>
				</div>
			</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?><?php /**PATH /var/www/html/demo/teamwork_7.0/resources/views/shared/render_log_timers.blade.php ENDPATH**/ ?>