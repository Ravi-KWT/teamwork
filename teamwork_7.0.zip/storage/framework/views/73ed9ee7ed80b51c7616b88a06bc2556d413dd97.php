<div class="clearfix">
  <?php if(Session::has('status')): ?>
  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
  <?php if(session('status')): ?>
  <div class="alert alert-success">
    <?php echo e(session('status')); ?>

  </div>
  <?php endif; ?>
  <?php endif; ?>

    <?php if(Session::has('info')): ?>
    <div class="alert alert-info" role="alert">
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
  <?php if(session('info')): ?>
  
    <?php echo e(session('info')); ?>

  
  <?php endif; ?>
  </div>
  <?php endif; ?>

    <?php if(Session::has('success')): ?>
        <div class="alert alert-success" role="alert">
      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
      </button>
      <?php if(session('success')): ?>
      
        <?php echo e(session('success')); ?>

      
      <?php endif; ?>
      </div>
      <?php endif; ?>




   <?php if(Session::has('error')): ?>
    <div class="alert alert-danger" role="alert">
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
  <?php if(session('error')): ?>
  
    <?php echo e(session('error')); ?>

  
  <?php endif; ?>
  </div>
  <?php endif; ?>
</div>

<?php /**PATH /var/www/html/demo/teamwork_7.0/resources/views/shared/session.blade.php ENDPATH**/ ?>